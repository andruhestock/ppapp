<div class="row">
<div class="col-md-12">
<h1>BIENVENIDO A KATANA</h1>
<p>Katana es un sistema de tienda en linea.</p>
</div>
</div>


<br><br>