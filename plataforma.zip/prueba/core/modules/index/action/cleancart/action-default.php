<?php

unset($_SESSION["cart"]);
Core::redir("index.php?view=mycart");

?>